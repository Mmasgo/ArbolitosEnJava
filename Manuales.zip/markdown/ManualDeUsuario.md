# **<span style="color:blue">MANUAL DE USUARIO**</span>
* <span style="color:green">UNIVERSIDAD MARIANO GÁLVEZ</span>
* <span style="color:green">SEDE: MAZATENANGO</span>
* <span style="color:green">CARRERA: INGENIERÍA EN SISTEMAS.</span>
* <span style="color:green">CURSO: PROGRAMACIÓN III</span>
* <span style="color:green">CATEDRATICO: ING. MIGUEL ANGEL LEMUS PINEDA.</span>
![visual studio code logo](uni.png)

* <span style="color:green">NOMBRE: MIRIAM ROSARIO MÁS GÓMEZ.</span>
* <span style="color:green">CARNÉ: 3090-22-3780</span>
* <span style="color:green">FECHA DE ENTREGA: 08/06/2024</span>

## INTRODUCCIÓN:
*Este manual de usuario tiene como objetivo brindar una guía completa y detallada sobre el uso de la aplicación de Árboles ABB y AVL. Esta herramienta ha sido diseñada para facilitar la gestión y manipulación de datos estructurados en forma de árboles binarios de búsqueda y árboles AVL (Árbol de Búsqueda Autobalanceado de Altura Equilibrada). El manual proporcionará instrucciones claras y precisas para aprovechar al máximo las funcionalidades de la aplicación, desde la carga de archivos hasta la visualización y modificación de los árboles.*

## Definición de la aplicación:
*La aplicación de Árboles ABB y AVL es un software de escritorio desarrollado en Java que permite al usuario cargar archivos de texto con datos estructurados, construir árboles binarios de búsqueda (ABB) y árboles AVL, y realizar diversas operaciones sobre estos árboles. Algunas de las principales funcionalidades incluyen la visualización gráfica de los árboles, la búsqueda y eliminación de nodos, la modificación de datos, y la encriptación y desencriptación de la información almacenada.* 


## MENÚ
En la ventana principal se podrá elegir cualquiera de las dos opciones, Arbol ABB o Arbol AVL.

![visual studio code logo](inicio.png)

## <span style="color:green">*ARBOL ABB*</span>

![visual studio code logo](ABB.png)

## CARGAR ARCHIVO
Dar Click en los tres puntitos, automaticamente aparecerá una ventana en donde podrá elegir un archivo txt.


![visual studio code logo](puntitos.png)

![visual studio code logo](cargar.png)

la aplicación mostrará dos mensajes, uno para seleccionar desde que línea quiere que se lea el documento.

![visual studio code logo](linea1.png)
![visual studio code logo](lineaF.png)

## CREAR NUEVO REGISTRO
Permite añadir un nuevo registro al arbol.

![alt text](Inscripcion.png)
![alt text](nuevoRe.png)


## ORDEN DE REGISTROS
Después de seleccionar el archivo puede seleccionar una de las opciones para ver el orden de los registros.
* InOrden
* PreOrden
* PostOrden

![visual studio code logo](ordenes.png)

Al seleccionar cualquiera de esos botones se mostrará en el areá de texto.
![visual studio code logo](Inorden.png)

## DIBUJO DEL ÁRBOL
cuando ya se tenga cargado el archivo se podrá visualizar el dibujo del arbol, esto será posible al presionar el botón de *"Ver ArbolABB"*
![visual studio code logo](DibujoABB.png)

## BUSCAR REGISTRO
Escriba un número de DPI (Documento Personal de Identificación) en la caja de texto, presione el botón de *"buscar"* y mostrará en la cajita de texto el nombre de la persona a quién le pertenece el DPI, si el DPI no existe, se mostrará en pantalla que no existe el nodo.

![visual studio code logo](resltadoB.png)

## ELIMINAR REGISTRO
Escriba un número de DPI (Documento Personal de Identificación) en la caja de texto, presione el botón de *"Eliminar"* y se mostrará en pantalla que el nodo fue eliminado, si el nodo no existe mostrará que no se encuentra.

![visual studio code logo](eliminar.png)

## MODIFICAR DATOS
Para poder modificar los datos de un nodo, primero se debe hacer una busqueda con el botón buscar, de esta manera se habilitará el botón de Modificar Datos, al realizar esta acción se mostrará en pantalla los espacios a llenar para que se añadán al registro existente.

![visual studio code logo](modificar.png)

### Los requisitos a llenar son:
+ Departamento al que pertenece.
+ Municipalidad al que pertenece.
+ Cantidad de Dosis que se le colocó.
+ Fecha de la primera Vacuna.
+ Fecha de la segunda Vacuna.
+ Fecha de la tercera Vacuna.
+ Lugar en donde fue vacunado.

![visual studio code logo](mod.png)

## ENCRIPTAR
Esta función permite darle seguridad a los registros, después de realizar modificaciones se podrá encriptar y automaticamente se crea un archivo en los documentos de la aplicación.

![visual studio code logo](ArEN.png)

## DESENCRIPTAR
Se habilita al encriptar los datos débido a que si se desea volver a los registros normales se pueda recuperar los datos desencriptados y visualizarlos en el mismo archivo que se creó en la carpeta del proyecto.

![visual studio code logo](ArDesen.png)

## <span style="color:green"> *ARBOL AVL*</span>

![visual studio code logo](AVL.png)

Esta ventana también contiene las mismas funciones que el Arbol ABB, con la diferencia de que en el dibujo se mostrará un Arbol Balanceado.

## CARGAR ARCHIVO
Dar Click en el boton en forma de lupa, automaticamente aparecerá una ventana en donde podrá elegir un archivo txt.
la aplicación mostrará dos mensajes, uno para seleccionar desde que línea quiere que se lea el documento.

![visual studio code logo](AVLpuntitos.png)

![visual studio code logo](cargar.png)

## CREAR NUEVO REGISTRO
Permite añadir un nuevo registro al arbol.

![alt text](nuevoAVL.png)

![alt text](mostrando.png)

## ORDEN DE REGISTROS
Después de seleccionar el archivo puede seleccionar una de las opciones para ver el orden de los registros.
* InOrden
* PreOrden
* PostOrden
![visual studio code logo](AVLOrdenes.png)
Al seleccionar cualquiera de esos botones se mostrará en el areá de texto.
![visual studio code logo](AVLInorden.png)

## DIBUJO DEL ÁRBOL
cuando ya se tenga cargado el archivo se podrá visualizar el dibujo del arbol, esto será posible al presionar el botón de *"Ver ArbolABB"*
![visual studio code logo](DibujoAVL.png)
## BUSCAR REGISTRO
Escriba un número de DPI (Documento Personal de Identificación) en la caja de texto, presione el botón de *"buscar"* y mostrará en la cajita de texto el nombre de la persona a quién le pertenece el DPI, si el DPI no existe, se mostrará en pantalla que no existe el nodo.

![visual studio code](BuscarAVL.png)

## ELIMINAR REGISTRO
Escriba un número de DPI (Documento Personal de Identificación) en la caja de texto, presione el botón de *"Eliminar"* y se mostrará en pantalla que el nodo fue eliminado, si el nodo no existe mostrará que no se encuentra.

![visual studio code logo](eliminarAVL.png)

## MODIFICAR DATOS
Para poder modificar los datos de un nodo, primero se debe hacer una busqueda con el botón buscar, de esta manera se habilitará el botón de Modificar Datos, al realizar esta acción se mostrará en pantalla los espacios a llenar para que se añadán al registro existente.

![visual studio code logo](mod.png)

### Los requisitos a llenar son:
+ Departamento al que pertenece.
+ Municipalidad al que pertenece.
+ Cantidad de Dosis que se le colocó.
+ Fecha de la primera Vacuna.
+ Fecha de la segunda Vacuna.
+ Fecha de la tercera Vacuna.
+ Lugar en donde fue vacunado.


## ENCRIPTAR
Esta función permite darle seguridad a los registros, después de realizar modificaciones se podrá encriptar y automaticamente se crea un archivo en los documentos de la aplicación.

![visual studio code logo](datosEn.png)

## DESENCRIPTAR
Se habilita al encriptar los datos débido a que si se desea volver a los registros normales se pueda recuperar los datos desencriptados y visualizarlos en el mismo archivo que se creó en la carpeta del proyecto.

![visual studio code logo](DatosDesEn.png)

## BOTÓN MENÚ

Finalmente un botón que permite volver al menú.

![alt text](boton.png)

## CONCLUCIONES
*Este manual de usuario proporciona una guía detallada para aprovechar al máximo las funcionalidades de la aplicación de Árboles ABB y AVL. Desde la carga de archivos hasta la visualización y manipulación de los árboles, el manual cubre todas las operaciones esenciales que el usuario necesita conocer para utilizar eficazmente esta poderosa herramienta.*

*Esta aplicación ha sido diseñada con el propósito de brindar una herramienta eficiente y fácil de usar para el manejo de estructuras de datos basadas en árboles, lo que resulta útil en diversos campos, como bases de datos, algoritmos de búsqueda y organización de información.*