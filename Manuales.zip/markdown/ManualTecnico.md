# **<span style="color:blue">MANUAL TÉCNICO**</span>
* <span style="color:green">UNIVERSIDAD MARIANO GÁLVEZ</span>
* <span style="color:green">SEDE: MAZATENANGO</span>
* <span style="color:green">CARRERA: INGENIERÍA EN SISTEMAS.</span>
* <span style="color:green">CURSO: PROGRAMACIÓN III</span>
* <span style="color:green">CATEDRATICO: ING. MIGUEL ANGEL LEMUS PINEDA.</span>
![visual studio code logo](uni.png)

* <span style="color:green">NOMBRE: MIRIAM ROSARIO MÁS GÓMEZ.</span>
* <span style="color:green">CARNÉ: 3090-22-3780</span>
* <span style="color:green">FECHA DE ENTREGA: 08/06/2024</span>



## Proposito:
### *El sistema está diseñado para gestionar y organizar información de vacunación de personas. Utiliza una estructura de datos de Árbol Binario de Búsqueda (ABB) y Arbol AVL para almacenar y eliminar eficientemente los datos basados en el número de DPI (Documento Personal de Identificación) de cada persona.*

## Funcionaldades:
* Agregar nuevos registros de vacunación manualmente 
* Agregar nuevos registros de vacunación por medio de archivo txt.
* Buscar registros por DPI
* Modificar información de vacunación
* Eliminar registros
* Visualizar datos en diferentes órdenes (in-orden, pre-orden, post-orden)
* Visualizar dibujo de los árboles.
* Encriptar y desencriptar datos modificados.
* Guardar los datos en un archivo.

## Componentes Principales
1. Nodos
2. Arboles
3. ArchivoTexto
4. Encriptación y desencriptación.
5. Graficas de arboles.

## Descripción de componentes

## *Arbol ABB*

## 1. Clase Nodo
### Propósito: Representa a un individuo y almacena su información de vacunación.
### Métodos:
 Constructor: Inicializa todos los atributos.

 Getters y Setters: Para acceder y modificar cada atributo.
 
![visual studio code logo](imagen1.png)
#### Se declaran los atributos y dos nodos, uno hijo izquierdo  y otro hijo derecho, se inicializan en el constructor como la imagen anterior.

## 2. Clase ArbolBB

### Propósito: 
Implementa la estructura de Árbol Binario de Búsqueda y sus operaciones.

### Atributos:

+ Raiz: Nodo raíz del árbol

+ nodoMod: Nodo temporalmente seleccionado para modificación

+ En: Instancia de EncriptacionArboles



### Métodos Principales:

* AgregarNodo: Añade un nuevo nodo al árbol basado en el DPI.
* BuscarNodo: Busca y retorna un nodo por su DPI.
* EliminarNodo: Elimina un nodo del árbol por su DPI.
* ObtenerNodoReemplazo: Maneja la lógica de reemplazo al eliminar un nodo.
* modificar: Actualiza la información de un nodo seleccionado.
* InOrden, PreOrden, PostOrden: Recorren el árbol en diferentes órdenes.
* datosdeNodo: para crear el archivo con los datos del nodo modificado.
* getdibujo: Retorna un para visualizar el árbol.JPanel



## Flujo de Datos y Algoritmos 
#### *a. Inserción (AgregarNodo)*
![visual studio code logo](AgregarNodo.png)
+ Si el árbol está vacío, el nuevo nodo se convierte en la raíz.
 Si no, se recorre el árbol.
 Si el DPI es menor, se va al hijo izquierdo.
 Si es mayor, se va al hijo derecho.
 Se repite hasta encontrar un lugar vacío.

#### *b. Búsqueda (BuscarNodo)*

Comienza desde la raíz.
Compara el DPI buscado con el nodo actual.
Si es igual, lo retorna.
Si es menor, va al hijo izquierdo; si es mayor, al derecho.
Repite hasta encontrarlo o llegar a un nodo nulo.

#### *c. Eliminación (EliminarNodo)*

Busca el nodo a eliminar.
Casos:

Sin hijos: Simplemente se elimina.
Un hijo: El hijo toma su lugar.
Dos hijos: Se reemplaza con el nodo más pequeño del subárbol derecho.








## 3. Carga de Datos (Clase ArchivoTexto)

### Propósito: Cargar datos de vacunación desde un archivo de texto a la estructura de árbol.

#### *Método Principal:*

cargarDatosDeArchivo(ArbolBB arch, String rutaArchivo, int lineaInicial, int LineaFinal)

#### Parámetros:

* arch: Instancia de ArbolBB donde se cargarán los datos
* rutaArchivo: Ruta al archivo de texto
* lineaInicial y LineaFinal: Rango de líneas a leer


#### Funcionamiento:

Abre y lee el archivo de texto línea por línea.
Omite la primera línea (encabezado).

Para cada línea en el rango especificado:
 
 Divide la línea en partes usando tabulador como separador.
 Extrae nombre y DPI.
 Convierte el DPI a long.
 Establece valores predeterminados para otros campos.
 Agrega un nuevo nodo al árbol con estos datos.
    
    public static void cargarDatosDeArchivo(ArbolBB arch, String rutaArchivo, int lineaInicial, int LineaFinal) {
    try {
        BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo));
        String linea = reader.readLine(); // Omitir la línea de encabezado
        int contador=0;
        

           while ((linea = reader.readLine()) != null){
               contador++;
               if(contador>=lineaInicial && contador <=LineaFinal){
            String[] partes = linea.split("\t"); // Separar el nombre y el DPI
            String nombre = partes[0].replaceAll("1", " ");
            String dpiST = partes[1];
            long dpi = Long.parseLong(dpiST);
                // Valores predeterminados para los datos adicionales de vacunación
                String departamento = "";
                String municipalidad = "";
                String dosis = "";
                String fecha1 = "";
                String fecha2 = "";
                String fecha3 = "";
                String lugarVacunacion = "";

                // Agregar el nodo con todos los datos
                arch.AgregarNodo(dpi, nombre, departamento, municipalidad, dosis, fecha1, fecha2, fecha3, lugarVacunacion);        }
           }
        reader.close();
    } catch (IOException e) {
        System.out.println("Ocurrió un error al leer el archivo: " + e.getMessage());
        e.printStackTrace();
    }


## 4. Visualización del Árbol (Clase ExpresionGraficaABB)

#### Propósito: 
+ Proporcionar una representación visual del Árbol Binario de Búsqueda.
+ Herencia: Extiende JPanel para integración con interfaces gráficas de Java.

### Atributos Clave:
+ miArbol: Instancia de ArbolBB a visualizar
+ posicionNodos: HashMap para almacenar posiciones de dibujo
+ subtreeSizes: HashMap para tamaños de subárboles

#### Funcionamiento:
En el constructor, se inicializan estructuras y se llama a repaint().
paint() es llamado por el sistema de Java.
* Se calculan posiciones y tamaños si es necesario.
* Se usa Graphics2D para dibujar nodos y líneas.
       
        public ExpresionGraficaABB(ArbolBB miArbol) {
          this.miArbol = miArbol;
          this.setBackground(Color.GRAY);
          posicionNodos = new HashMap();
          subtreeSizes = new HashMap();
          dirty = true;
          repaint();  //metodo que pinta el arbol  
        }

#### Características:
Ajusta automáticamente el diseño basado en el tamaño del texto y la estructura del árbol.
Centra el árbol en el panel.
Maneja diferentes tamaños de subárboles.

#### Métodos Principales:
+ calcularPosiciones(): Prepara datos para el dibujo.
    
      private void calcularPosiciones() 
       {
          posicionNodos.clear();
         subtreeSizes.clear();
         Nodo root = this.miArbol.raiz;
         if (root != null) 
         {
             calcularTamañoSubarbol(root);
             calcularPosicion(root, Integer.MAX_VALUE, Integer.MAX_VALUE, 0);
         }
      } 

+ calcularTamañoSubarbol(Nodo n): Calcula dimensiones de cada subárbol.


        private Dimension calcularTamañoSubarbol(Nodo n) 
       {
        if (n == null) 
              return new Dimension(0,0);
 
          Dimension ld = calcularTamañoSubarbol(n.HijoIzquierdo);
          Dimension rd = calcularTamañoSubarbol(n.HijoDerecho);
          
          int h = fm.getHeight() + parent2child + Math.max(ld.height, rd.height);
          int w = ld.width + child2child + rd.width;
          
          Dimension d = new Dimension(w, h);
          subtreeSizes.put(n, d);
          
          return d;
       }

+ calcularPosicion(Nodo n, int left, int right, int top): Determina la posición de cada nodo.

      private void calcularPosicion(Nodo n, int left, int right, int top) 
      {
      if (n == null) 
          return;
      
      Dimension ld = (Dimension) subtreeSizes.get(n.HijoIzquierdo);
      if (ld == null) 
          ld = empty;
      
      Dimension rd = (Dimension) subtreeSizes.get(n.HijoDerecho);
      if (rd == null) 
          rd = empty;
      
      int center = 0;
      
      if (right != Integer.MAX_VALUE)
          center = right - rd.width - child2child/2;
      else if (left != Integer.MAX_VALUE)
          center = left + ld.width + child2child/2;
      int width = fm.stringWidth(n.dpi+"");
 
      posicionNodos.put(n,new Rectangle(center - width/2 - 3, top, width + 6, fm.getHeight()));
      
      calcularPosicion(n.HijoIzquierdo, Integer.MAX_VALUE, center - child2child/2, top + fm.getHeight() + parent2child);
      calcularPosicion(n.HijoDerecho, center + child2child/2, Integer.MAX_VALUE, top + fm.getHeight() + parent2child);
      }

+ dibujarArbol(Graphics2D g, Nodo n, int puntox, int puntoy, int yoffs): Dibuja el árbol recursivamente.

      private void dibujarArbol(Graphics2D g, Nodo n, int puntox, int puntoy, int yoffs) 
      {
       if (n == null) 
         return;
     
       Rectangle r = (Rectangle) posicionNodos.get(n);
       g.draw(r);
       g.drawString(n.dpi+"", r.x + 3, r.y + yoffs);
   
       if (puntox != Integer.MAX_VALUE)
       
       g.drawLine(puntox, puntoy, (int)(r.x + r.width/2), r.y);
     
       dibujarArbol(g, n.HijoIzquierdo, (int)(r.x + r.width/2), r.y + r.height, yoffs);
       dibujarArbol(g, n.HijoDerecho, (int)(r.x + r.width/2),  r.y + r.height, yoffs);
     
      } 


+ paint(Graphics g): Método principal que inicia el proceso de dibujo.
       
        public void paint(Graphics g) 
        {
         super.paint(g);
         fm = g.getFontMetrics();

         if (dirty) 
         {
           calcularPosiciones();
           dirty = false;
         }
         
         
         Graphics2D g2d = (Graphics2D) g;
         g2d.translate(getWidth() / 2, parent2child);
         dibujarArbol(g2d, this.miArbol.raiz, Integer.MAX_VALUE, Integer.MAX_VALUE, 
                  fm.getLeading() + fm.getAscent());
         fm = null;
        }
    



### Integración de Componentes
La clase ArbolBB tiene un método getdibujo() que retorna una instancia de ExpresionGraficaABB.
Esto permite a otras partes del sistema (ej: ventanas de la interfaz) obtener y mostrar la visualización del árbol.
La carga de datos y la visualización están desacopladas:
      
       public JPanel getdibujo() {
        return new ExpresionGraficaABB(this);
    }

ArchivoTexto carga datos en el árbol.
ExpresionGraficaABB lee el árbol y lo visualiza.





## 5. Seguridad de Datos (Clase EncriptacionArboles)
### Propósito:
 Proporcionar funcionalidades para encriptar, desencriptar y persistir datos del árbol.

### *Atributos Principales:*
miArchivoBBT: Archivo para almacenar datos encriptados.
* Constructor.

       public EncriptacionArboles() {
        miArchivoBBT = new File("archivoABB.txt"); // Inicializa el archivo en el constructor
        try {
            if (!miArchivoABB.exists()) {
                miArchivoABB.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
      }

### Métodos Clave:
* crearArchivo(Nodo nodo):
Guarda los datos de un nodo en el archivo.
Usa '/' como delimitador entre campos.
      
      public void crearArchivo(Nodo nodo) {
    
        FileWriter escribir;
        PrintWriter lineaWriter;  // Para escribir en el archivo
        String nombre = "", departamento = "", municipio = "", cantidad = "", primerFvacuna = "", segundaFvacuna = "", tercerarFvacuna = "", lugarVacunacion = "";
        
        
        try {
            escribir = new FileWriter(miArchivoABB, true); // true para modo append
            lineaWriter = new PrintWriter(escribir);
            
            // Escribir en el archivo
            lineaWriter.println(nodo.dpi + "/" + nodo.nombre + "/" + nodo.departamento + "/" + nodo.municipalidad + "/" + nodo.dosis + "/" + nodo.fecha1 + "/" + nodo.fecha2 + "/" + nodo.fecha3+ "/" + nodo.lugarVacunacion);
            
            // Cerrar los recursos
            lineaWriter.close();
            escribir.close();
        } catch (IOException e) {
            e.printStackTrace();
        }
        }

* cargar(ArbolBB arbolito):
Lee datos del archivo y los añade al árbol.
Maneja errores e informa al usuario.
      
      public void cargar(ArbolBB arbolito){
        try{
            FileReader archivo = new FileReader("archivoABB.txt");
            BufferedReader lectura = new BufferedReader(archivo);
            
            String linea;
            
            while((linea = lectura.readLine()) != null){
            String[] fila = linea.split("/");
                if(fila.length == 9){
                             
                    long dpi = Long.parseLong(fila[0]);
                    arbolito.AgregarNodo(dpi, fila[1], fila[2], fila[3], fila[4], fila[5], fila[6], fila[7], fila[8]);
              
                }
            }
            JOptionPane.showMessageDialog(null, "Inscripcción Correcta");
        }catch(IOException | NumberFormatException e){
            JOptionPane.showMessageDialog(null, "Inscripcion Fallida");
            
        }
        
       }

* encriptar(String texto) y desEncrip(String texto):
Implementan un algoritmo de sustitución simple (+3/-3).
Manejan letras (mayúsculas y minúsculas) y dígitos.
    
  
    
        public static String encriptar(String texto) {
            StringBuilder resultado = new StringBuilder();
            for (int i = 0; i < texto.length(); i++) {
                char caracter = texto.charAt(i);
                if (Character.isLetter(caracter)) {
                    caracter = (char) (caracter + 3); // Desplazamiento de 3 posiciones
                    if ((caracter > 'z' && Character.isLowerCase(texto.charAt(i))) ||
                        (caracter > 'Z' && Character.isUpperCase(texto.charAt(i)))) {
                        caracter = (char) (caracter - 26); // Ajuste para evitar desbordamiento
                    }
                } else if (Character.isDigit(caracter)) {
                    caracter = (char) ((caracter - '0' + 3) % 10 + '0'); // Desplazamiento de 3 dígitos
                }
                resultado.append(caracter);
            }
            return resultado.toString();
        }

        public static String desEncrip(String texto) {
            StringBuilder resultado = new StringBuilder();
            for (int i = 0; i < texto.length(); i++) {
                char caracter = texto.charAt(i);
                if (Character.isLetter(caracter)) {
                    caracter = (char) (caracter - 3); // Desplazamiento de -3 posiciones
                    if ((caracter < 'a' && Character.isLowerCase(texto.charAt(i))) ||
                        (caracter < 'A' && Character.isUpperCase(texto.charAt(i)))) {
                        caracter = (char) (caracter + 26); // Ajuste para evitar desbordamiento
                    }
                } else if (Character.isDigit(caracter)) {
                    caracter = (char) ((caracter - '0' - 3 + 10) % 10 + '0'); // Desplazamiento de -3 dígitos
                }
                resultado.append(caracter);
            }
            return resultado.toString();
        }


* encriptarArchivo(File archivo) y desencriptarArchivo(File archivo):
Encriptan y desencriptan archivos completos.
      
      public static  void encriptarArchivo(File archivo) throws IOException {
        Path path = Paths.get(archivo.getAbsolutePath());
        String contenido = new String(Files.readAllBytes(path));
        String contenidoEncriptado = encriptar(contenido);
        Files.write(path, contenidoEncriptado.getBytes());
       }
    
        public void desencriptarArchivo(File archivo) throws IOException {
        Path path = Paths.get(archivo.getAbsolutePath());
        String contenido = new String(Files.readAllBytes(path));
        String contenidoDesencriptado = desEncrip(contenido);
        Files.write(path, contenidoDesencriptado.getBytes());
      }

* encriptarArbol(Nodo nodo) y desencriptarArbol(Nodo nodo):
Aplican encriptación y desencriptación a todos los campos de un nodo y sus hijos.

        public void encriptarArbol(Nodo nodo) {
        if (nodo != null) {
          
      nodo.dpi =Long.parseLong(encriptar(Long.toString(nodo.dpi)));
            nodo.nombre = encriptar(nodo.nombre);
            nodo.departamento = encriptar(nodo.departamento);
            nodo.municipalidad = encriptar(nodo.municipalidad);
            nodo.dosis= encriptar(nodo.dosis);
            nodo.fecha1 = encriptar(nodo.fecha1);
            nodo.fecha2 = encriptar(nodo.fecha2);
            nodo.fecha3 = encriptar(nodo.fecha3);
            nodo.lugarVacunacion = encriptar(nodo.lugarVacunacion);
            encriptarArbol(nodo.HijoIzquierdo);
            encriptarArbol(nodo.HijoDerecho);
          
        }
       }
     
    
        public void desencriptarArbol(Nodo nodo) {
        if (nodo != null) {
            
            nodo.dpi = Long.parseLong(desEncrip(Long.toString(nodo.dpi)));
            nodo.nombre = desEncrip(nodo.nombre);
            nodo.departamento = desEncrip(nodo.departamento);
            nodo.municipalidad = desEncrip(nodo.municipalidad);
            nodo.dosis = desEncrip(nodo.dosis);
            nodo.fecha1 = desEncrip(nodo.fecha1);
            nodo.fecha2 = desEncrip(nodo.fecha2);
            nodo.fecha3 = desEncrip(nodo.fecha3);
            nodo.lugarVacunacion = desEncrip(nodo.lugarVacunacion);
            desencriptarArbol(nodo.HijoIzquierdo);
            desencriptarArbol(nodo.HijoDerecho);
        }
      }

## 6. JFrame form Ventana:
### Propósito:
 crear dos botones, uno para llamar a la ventana de Árbol de búsqueda y otro para llamar el árbol AVL.

## 7. interfaz ArboldeBusqueda:
### Propósito: 
llamar a los métodos de las clases anteriores para darle funcionamiento.
* se crea un objeto de la clase arbol que almacenara todos los nodos.

 `private ArbolBB arbolito;`

*	Botón para cargar el archivo: crea un bjeto de JFileChooser para abrir una ventanita y que permita seleccionar un archivo txt, se llama a la clase archivoTexto y al método cargarDatosDeArchivo enviando al arbolito, la ruta del archivo y el rango de líneas que leerá.

         private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        arbolito=new ArbolBB();
        JFileChooser fc= new JFileChooser();//creando objeto
        
        //creando un filtro para archivos txt
        FileNameExtensionFilter filtro=new FileNameExtensionFilter(".TXT", "txt");
        
        //indicamos el filtro
        fc.setFileFilter(filtro);
        
        //abriendo ventana, guardamos la opcion seleccionada por el usuario        
        int seleccion=fc.showOpenDialog(this);
        
        //si el usuario selecciona aceptar
        if (seleccion==JFileChooser.APPROVE_OPTION){
            //seleccionamos el fichero
            File fichero=fc.getSelectedFile();
             
            //Escribe la ruta del fichero sleccionado en el campo de texto
            this.textField1.setText(fichero.getAbsolutePath());
            int LI =Integer.parseInt(JOptionPane.showInputDialog(null, "ingresa el numero de linea INICIAL que desea cargar"));
            int LF =Integer.parseInt(JOptionPane.showInputDialog(null, "ingresa el numero de linea FINAL que desea cargar"));
 
           
            //agregando al arbol
            ArchivoTexto.cargarDatosDeArchivo(arbolito, fichero.getAbsolutePath(), LI, LF); 
            
        }
        
        } 

*	BotonIn: si el arbolito no esta vacío se llama al método InOrden de la clase ArbolBB.
*	BotonPre: si el arbolito no esta vacío se llama al método PreOrden de la clase ArbolBB.
*	BotonPost: si el arbolito no esta vacío se llama al método PostOrden de la clase ArbolBB.
  
        private void BotonInActionPerformed(java.awt.event.ActionEvent evt) {                                        
        StringBuilder sb=new StringBuilder();
        
        JTextArea.setText("");//limpiar Text
        
        //llamar al metodo InOrden y capturar la salida en el StringBuilder
        if(arbolito != null && !arbolito.EstaVacio()){
            arbolito.InOrden(arbolito.raiz,sb);
    
        }
        JTextArea.setText(sb.toString());//mostrar la salida en el text
    
      }                                       

     private void BotonPreActionPerformed(java.awt.event.ActionEvent evt) {                                         

        StringBuilder sb=new StringBuilder();
        
        JTextArea.setText("");//limpiar Text
        
        //llamar al metodo InOrden y capturar la salida en el StringBuilder
        if(arbolito != null && !arbolito.EstaVacio()){
            arbolito.PreOrden(arbolito.raiz,sb);
        }
        JTextArea.setText(sb.toString());//mostrar la salida en el text
    }                                        

    private void BotonPostActionPerformed(java.awt.event.ActionEvent evt) {                                          
      
        StringBuilder sb=new StringBuilder();
        
        JTextArea.setText("");//limpiar Text
        
        //llamar al metodo InOrden y capturar la salida en el StringBuilder
        if(arbolito != null && !arbolito.EstaVacio()){
            arbolito.PostOrden(arbolito.raiz,sb);
        }
        JTextArea.setText(sb.toString());//mostrar la salida en el text
       } 

*	Boton Buscar: si crea un nodo temporal de la clase Nodo, se le asigna el método buscar nodo de la clase ArbolBB, si este nodo temporal es nulo (no existe) mostrará mensaje de que no existe el nodo, de lo contrario se mostrará el nombre del nodo en el text area.
  
         private void BuscarActionPerformed(java.awt.event.ActionEvent evt) {                                       
     
         if(!arbolito.EstaVacio()){
         String dpi1=textBuscar.getText();
       
         long dpi = Long.parseLong(dpi1);
         Nodo tmp;
        tmp=arbolito.BuscarNodo(dpi);
        if(tmp==null){
        JOptionPane.showMessageDialog(null,"el nodo a buscar no se encuenta","error",JOptionPane.QUESTION_MESSAGE);
        }else{
                    JTextArea.setText("");//limpiar Text
                   JTextArea.setText(tmp.getNombre());//mostrar la salida en el text  
                   modificarDatos.setEnabled(true);
        }
           }else{
           JOptionPane.showMessageDialog(null, "esta vacio", "error", JOptionPane.INFORMATION_MESSAGE);
             }
       
        } 

*	Boton Eliminar: verifica si el árbol no está vacío, se obtiene el dato que se desea eliminar del campo de texto. Si el nodo se elimina correctamente, se muestra un mensaje indicando que el nodo ha sido eliminado. Si el nodo no se encuentra en el árbol, se muestra un mensaje indicando que el nodo no se encontró. En caso de que el árbol esté vacío, se muestra un mensaje de error indicando que el árbol está vacío.
         
          private void EliminarActionPerformed(java.awt.event.ActionEvent evt) {                                         
  
        
           if(!arbolito.EstaVacio()){
               String dat=textBuscar.getText();
               long dato=Long.parseLong(dat);
      
           if (arbolito.EliminarNodo(dato)==false){
            JOptionPane.showMessageDialog(null, "El Nodo a Eliminar no se encuentra en el Arbol","Nodo no Encontrado",JOptionPane.INFORMATION_MESSAGE);
               }else{
               JOptionPane.showMessageDialog(null, "El Nodo ha sido eliminado del Arbol","Nodo Eliminado",JOptionPane.INFORMATION_MESSAGE);
                    }
                }else{
                   JOptionPane.showMessageDialog(null, "El Arbol esta vacio","Error",JOptionPane.INFORMATION_MESSAGE);
                    }

        }  

*	JButton2: crea una ventana de JFrame enviando un objeto de la clase ExpresionGraficaABB para mostrar el dibujo.
    
        private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        // TODO add your handling code here:
        ExpresionGraficaABB graf= new ExpresionGraficaABB(arbolito);
        JFrame ventana=new JFrame();
        ventana.getContentPane().add(graf);
        ventana.setSize(800, 600);
        ventana.setVisible(true);
        ventana.setLocationRelativeTo(null);
        } 

*	Bontón Insertar: crea una variable tipo long y un String para almacenar el DPI y nombre de la persona, la agregar al arbolito.
            

                    String nuevoD=textNuevoDPI.getText();
            try {
                long dato = Long.parseLong(nuevoD);
                String nombre = textNuevoNom.getText();
                arbolito.AgregarNodo(dato, nombre, "", "", "", "", "", "", "");
            } catch (NumberFormatException e) {
                // Maneja el caso de error cuando el texto ingresado no es un número válido
                System.out.println("El valor ingresado para el DPI no es un número válido.");
            } catch (Exception e) {
                // Maneja cualquier otra excepción que pueda ocurrir
                System.out.println("Error al insertar nodo en el árbol: " + e.getMessage());
            }

*	Botón modificar: crea 7 variables tpo string para guardar la actualización de datos de las personas vacunadas, 
    
        private void modificarDatosActionPerformed(java.awt.event.ActionEvent evt) {                                               
            // TODO add your handling code here:
            String dep=JOptionPane.showInputDialog(null,"Departamento");
            String muni=JOptionPane.showInputDialog(null,"municipalidad");
            String Dosis=JOptionPane.showInputDialog(null,"Dosis");
            String Fecha1=JOptionPane.showInputDialog(null,"Fecha 1");
            String Fecha2=JOptionPane.showInputDialog(null,"Fecha 2");
            String Fecha3=JOptionPane.showInputDialog(null,"Fecha 3");
            String Lugar=JOptionPane.showInputDialog(null,"Lugar de Vacunacion");

            arbolito.modificar(dep, muni, Dosis, Fecha1, Fecha2, Fecha3, Lugar);
            arbolito.datosdeNodo();
        }

* Boton  encriptar: crea un objeto de la clase EncriptacionArboles, le mandamos la raíz del arbolito y llamamos al metodo de encriptar archivo enviando el nombre de nuestro archivo. De la misma forma en el boton desencriptar. 
     
        private void encriptarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        EncriptacionArboles en=new EncriptacionArboles();
            
        try {
            en.encriptarArbol(arbolito.raiz);
            en.encriptarArchivo(en.getMiArchivoABB());
        Desencriptar.setEnabled(true);
        } catch (IOException ex) {
            Logger.getLogger(ArboldeBusqueda.class.getName()).log(Level.SEVERE, null, ex);
        }
        
        }                                         


            
        private void DesencriptarActionPerformed(java.awt.event.ActionEvent evt) {                                             
     
        EncriptacionArboles en=new EncriptacionArboles();
        
            try {
            en.desencriptarArbol(arbolito.raiz);
            en.desencriptarArchivo(en.getMiArchivoABB());
            } catch (IOException ex) {
            Logger.getLogger(ArboldeBusqueda.class.getName()).log(Level.SEVERE, null, ex);
        }

 ## 8. Clase Principal
creamos un objeto de nuestro JFrame Ventana para visualizarla.

     public static void main(String[] args) {
       Ventana principal= new Ventana();
       principal.setVisible(true);
       principal.setLocationRelativeTo(null);   
    }       

## *ARBOL AVL*
Implementa un Árbol AVL (Árbol de Búsqueda Autobalanceado de Altura Equilibrada) y proporciona una interfaz gráfica de usuario para interactuar con él. Permite cargar datos desde un archivo de texto, visualizar el árbol, realizar operaciones como recorridos, búsqueda, eliminación y modificación de nodos, así como encriptar y desencriptar los datos.

## 9.  Clase (NodoAVL)
Esta clase contiene los mismos atributos y metodos que la clase nodo del ABB, con la diferencia que añadiremos un entero llamado fe que es el Factor de Equilibrio.

        int fe;
        NodoAVL HijoIzquierdo;
        NodoAVL HijoDerecho;

* Constructor: se inicalizan los demas atributos y lo nodos y el factor de equilibrio quedarán así:

        this.fe=0;
        this.HijoIzquierdo=null;
        this.HijoDerecho=null; 

## 10. Clase (Arbol AVL)
### Declaración de variables:

* nodoMod: Un NodoAVL que se utiliza para almacenar un nodo modificado.
* En: Un objeto de tipo EncripAVL que se utiliza para la encriptación de datos.
* raiz: Un NodoAVL que representa la raíz del árbol AVL.

        public NodoAVL nodoMod;
        private EncripAVL En;

            public NodoAVL raiz;
            

### Constructor:

ArbolAVL(): El constructor de la clase que inicializa la raíz como nula y crea una instancia de EncripAVL.
    
    public ArbolAVL(){
        raiz=null;
        this.En=new EncripAVL();
    }
    
    

### Métodos:

* EstaVacio(): Verifica si el árbol está vacío (sin nodos).
    
    public boolean EstaVacio(){
         return raiz==null;
    }

* buscar(long d): Busca un nodo en el árbol según el DPI dado y devuelve el nodo encontrado. Si no se encuentra, devuelve null.

        public NodoAVL buscar(long d){
         NodoAVL r;

          NodoAVL aux=raiz;
          String nom;
          while(aux.dpiAVL!=d){
              if(d<aux.dpiAVL){
                  aux=aux.HijoIzquierdo;      
              }else{
                  aux=aux.HijoDerecho;
              }
              if(aux==null){
                  return null;
              }
          }
          nodoMod=aux;
          return aux;  
      }

* ObtenerFE(NodoAVL x): Obtiene el factor de equilibrio de un nodo dado.

        public int ObtenerFE(NodoAVL x){
            if(x==null){
                return -1;
            }else{
                return x.fe;
            }
        }
        

* balance(NodoAVL equilibrio): Calcula el factor de equilibrio de un nodo dado.

        public int balance(NodoAVL equilibrio){
            if(equilibrio==null){
                return 0;
            }
            return ObtenerFE(equilibrio.HijoIzquierdo)-ObtenerFE(equilibrio.HijoDerecho);
        }
        
* rotacionIzquierda(NodoAVL c) y rotacionDerecha(NodoAVL c): Realizan rotaciones simples a la izquierda y derecha, respectivamente, para mantener el equilibrio del árbol.

        public NodoAVL rotacionIzquierda (NodoAVL c){
            NodoAVL aux=c.HijoIzquierdo;
            c.HijoIzquierdo=aux.HijoDerecho;
            aux.HijoDerecho=c;
            c.fe=Math.max(ObtenerFE(c.HijoIzquierdo),ObtenerFE(c.HijoDerecho))+1;//metodo que devuelve el maximo de dos valores
            aux.fe=Math.max(ObtenerFE(aux.HijoIzquierdo),ObtenerFE(aux.HijoDerecho))+1;
            return aux;
        }
       
        //rotacion simple a la derecha
      public NodoAVL rotacionDerecha (NodoAVL c){
        NodoAVL aux=c.HijoDerecho;
        c.HijoDerecho=aux.HijoIzquierdo;
        aux.HijoIzquierdo=c;
        c.fe=Math.max(ObtenerFE(c.HijoIzquierdo),ObtenerFE(c.HijoDerecho))+1;//metodo que devuelve el maximo de dos valores
        aux.fe=Math.max(ObtenerFE(aux.HijoIzquierdo),ObtenerFE(aux.HijoDerecho))+1;
        return aux;
       }

* rotacionDobleIzquierda(NodoAVL c) y rotacionDobleDerecha(NodoAVL c): Realizan rotaciones dobles a la izquierda y derecha, respectivamente, para mantener el equilibrio del árbol.


    //rotacion doble a la derecha
    public NodoAVL rotacionDobleIzquierda(NodoAVL c){
        NodoAVL temp;
        c.HijoIzquierdo=rotacionDerecha(c.HijoIzquierdo);
        temp=rotacionIzquierda(c);
        return temp;
    }    
    
    //rotacion doble a la izquierda
    public NodoAVL rotacionDobleDerecha(NodoAVL c){
        NodoAVL temp;
        c.HijoDerecho=rotacionIzquierda(c.HijoDerecho);
        temp=rotacionDerecha(c);
        return temp; 
    }

* insertarAVL(NodoAVL nuevo, NodoAVL subAr): Inserta un nuevo nodo en el árbol AVL y realiza rotaciones si es necesario para mantener el equilibrio.

        public NodoAVL insertarAVL(NodoAVL nuevo, NodoAVL subAr){
            NodoAVL nuevoPadre=subAr;
            if(nuevo.dpiAVL<subAr.dpiAVL){
                if(subAr.HijoIzquierdo==null){
                    subAr.HijoIzquierdo=nuevo;
                }else{
                    subAr.HijoIzquierdo=insertarAVL(nuevo, subAr.HijoIzquierdo);
                    if((ObtenerFE(subAr.HijoIzquierdo)-ObtenerFE(subAr.HijoDerecho)==2)){
                        if(nuevo.dpiAVL<subAr.HijoIzquierdo.dpiAVL){
                            nuevoPadre=rotacionIzquierda(subAr);
                        }else{
                            nuevoPadre=rotacionDobleIzquierda(subAr);
                        }
                    }
                }
            }else if(nuevo.dpiAVL>subAr.dpiAVL){
                if(subAr.HijoDerecho==null){
                    subAr.HijoDerecho=nuevo;
                }else{
                    subAr.HijoDerecho=insertarAVL(nuevo, subAr.HijoDerecho);
                    if((ObtenerFE(subAr.HijoDerecho)-ObtenerFE(subAr.HijoIzquierdo)==2)){
                        if(nuevo.dpiAVL>subAr.HijoDerecho.dpiAVL){
                            nuevoPadre=rotacionDerecha(subAr);
                        }else{
                            nuevoPadre=rotacionDobleDerecha(subAr);
                        }
                    }
                }
            }else{
                System.out.println("Nodo duplicado");
            }
            //actualizando altura
            if((subAr.HijoIzquierdo==null)&&(subAr.HijoDerecho!=null)){
                subAr.fe=subAr.HijoDerecho.fe+1;           
            }else if((subAr.HijoDerecho==null)&&(subAr.HijoIzquierdo!=null)){
                subAr.fe=subAr.HijoIzquierdo.fe+1;
            }else{
                subAr.fe=Math.max(ObtenerFE(subAr.HijoIzquierdo), ObtenerFE(subAr.HijoDerecho))+1;
            }
            return nuevoPadre;
        }

* insertar(long dpi, String nombre, String departamento, String municipalidad, String dosis, String fecha1, String fecha2, String fecha3, String lugarVacunacion): Crea un nuevo nodo con los datos proporcionados y lo inserta en el árbol.

        public void insertar(long dpi, String nombre,String departamento, String municipalidad, String dosis, String fecha1, String fecha2, String fecha3, String lugarVacunacion){
            NodoAVL nuevo= new NodoAVL(dpi, nombre, departamento,municipalidad,dosis, fecha1, fecha2, fecha3, lugarVacunacion);
            if(raiz==null){
                raiz=nuevo;
            }else{
                raiz=insertarAVL(nuevo, raiz);
            }
        }

* InOrden(NodoAVL r, StringBuilder sb), PreOrden(NodoAVL r, StringBuilder sb) y PostOrden(NodoAVL r, StringBuilder sb): Realizan recorridos en orden, pre-orden y post-orden del árbol, respectivamente, y almacenan los datos de los nodos en un StringBuilder.

            public void InOrden(NodoAVL r, StringBuilder sb){
            if(r!=null){
                InOrden(r.HijoIzquierdo,sb);
                sb.append(r.dpiAVL).append(" ").append(r.nombre).append(" ").append(r.departamento).append(" ").append(r.municipalidad).append(" ").append(r.dosis).append(" ").append(r.fecha1).append(" ").append(r.fecha2).append(" ").append(r.fecha3).append(" ").append(r.lugarVacunacion).append("\n");
                InOrden(r.HijoDerecho,sb);
            }
        }
        public void PreOrden(NodoAVL r, StringBuilder sb){
            if(r!=null){
                sb.append(r.dpiAVL).append("\n");
                PreOrden(r.HijoIzquierdo,sb);
                PreOrden(r.HijoDerecho,sb);
            }
        }
        
        public void PostOrden(NodoAVL r, StringBuilder sb){
            if(r!=null){
                PostOrden(r.HijoIzquierdo,sb);
                PostOrden(r.HijoDerecho,sb);
            sb.append(r.dpiAVL).append("\n");
            }
        }

* eliminarAVL(Long dpiAVL): Elimina un nodo del árbol según el DPI dado.

      public boolean eliminarAVL(Long dpiAVL){
          raiz=EliminarNodo(raiz,dpiAVL);
          return true;
      }

* EliminarNodo(NodoAVL nodoActual, Long dpiAVL): Método auxiliar que elimina un nodo del árbol y realiza rotaciones para mantener el equilibrio.

        public NodoAVL EliminarNodo(NodoAVL nodoActual, Long dpiAVL){
        if (nodoActual == null) {
                return nodoActual;
            }

        if (dpiAVL < nodoActual.dpiAVL) {
            nodoActual.HijoIzquierdo = EliminarNodo(nodoActual.HijoIzquierdo, dpiAVL);
        } else if (dpiAVL > nodoActual.dpiAVL) {
            nodoActual.HijoDerecho = EliminarNodo(nodoActual.HijoDerecho, dpiAVL);
        } else { // nodo a eliminar encontrado
            // con un hijo o sin hijos
            if ((nodoActual.HijoIzquierdo == null) || (nodoActual.HijoDerecho == null)) {
                NodoAVL temporal = null;
                
                if (temporal == nodoActual.HijoIzquierdo) {
                    temporal = nodoActual.HijoDerecho;
                } else {
                    temporal = nodoActual.HijoIzquierdo;
                }

                // si no tiene hijos
                if (temporal == null) {
                    temporal = nodoActual;
                    nodoActual = null;
                } else {
                    // con un hijo
                    nodoActual = temporal;
                }
            } else {
                NodoAVL temporal = obtenerSucesor(nodoActual.HijoDerecho);
            nodoActual.dpiAVL = temporal.dpiAVL;
                nodoActual.HijoDerecho = EliminarNodo(nodoActual.HijoDerecho, temporal.dpiAVL);
            }
        }

        if (nodoActual != null) {
            // actualizar altura y balancear
            nodoActual = balancearNodo(nodoActual);
        }

                        return nodoActual;
        }

* balancearNodo(NodoAVL nodoActual): Actualiza la altura de un nodo y realiza rotaciones si es necesario para mantener el equilibrio del árbol.

        private NodoAVL balancearNodo(NodoAVL nodoActual) {
        // actualizar altura
        nodoActual.fe = Math.max(ObtenerFE(nodoActual.HijoIzquierdo), ObtenerFE(nodoActual.HijoDerecho)) + 1;
        int factorE = balance(nodoActual);

        // realizar rotaciones
        if (factorE > 1) {
            if (balance(nodoActual.HijoIzquierdo) >= 0) {
                nodoActual = rotacionDerecha(nodoActual);
            } else {
                nodoActual = rotacionDobleIzquierda(nodoActual);
            }
        } else if (factorE < -1) {
            if (balance(nodoActual.HijoDerecho) <= 0) {
                nodoActual = rotacionIzquierda(nodoActual);
            } else {
                nodoActual = rotacionDobleDerecha(nodoActual);
            }
        }

        return nodoActual;
       }

* obtenerSucesor(NodoAVL node): Obtiene el nodo sucesor de un nodo dado.
       
        private NodoAVL obtenerSucesor(NodoAVL node) {
            NodoAVL sucesorpadre=null;
               NodoAVL sucesor=node.HijoDerecho;
               
               while(sucesor.HijoIzquierdo!=null){
                   sucesorpadre=sucesor;
                   sucesor=sucesor.HijoIzquierdo;
               }
               
               if(sucesorpadre!=null){
                   sucesorpadre.HijoIzquierdo=sucesor.HijoDerecho;
               }else{
                   node.HijoDerecho=sucesor.HijoDerecho;
               }
               sucesor.HijoIzquierdo = node.HijoIzquierdo;
                sucesor.HijoDerecho = node.HijoDerecho;
               return sucesor;
            }

* modificar(String departamento, String municipalidad, String dosis, String fecha1, String fecha2, String fecha3, String lugarVacunacion): Modifica los datos de un nodo seleccionado previamente.

        public void modificar(String departamento, String municipalidad, String dosis, String fecha1, String fecha2, String fecha3, String lugarVacunacion){
            if (nodoMod != null) {
                nodoMod.setDepartamento(departamento);
                nodoMod.setMunicipalidad(municipalidad);
                nodoMod.setDosis(dosis);
                nodoMod.setFecha1(fecha1);
                nodoMod.setFecha2(fecha2);
                nodoMod.setFecha3(fecha3);
                nodoMod.setLugarVacunacion(lugarVacunacion);
            } else {
                System.out.println("Error: No se ha seleccionado ningún nodo para modificar.");
            }
            }

* datosdeNodo(): Crea un archivo con los datos del nodo seleccionado previamente.

       public void datosdeNodo(){
      En.crearArchivo(nodoMod);
      }

* getdibujo(): Devuelve un panel gráfico que representa el árbol AVL.

        public JPanel getdibujo() {
            return new GraficaAVL(this);
        }
      }
## 11. (Clase ArchivoTexto)

Esta clase ya se ha creado anteriormente, solo se agrega un metodo para cargar los datos al arbol AVL.
        
        public static void cargarArchivoAVL(ArbolAVL arch, String rutaArchivo, int lineaInicial, int LineaFinal) {
    try {
        BufferedReader reader = new BufferedReader(new FileReader(rutaArchivo));
        String linea = reader.readLine(); // Omitir la línea de encabezado
        int contador=0;
        

           while ((linea = reader.readLine()) != null){
               contador++;
               if(contador>=lineaInicial && contador <=LineaFinal){
            String[] partes = linea.split("\t"); // Separar el nombre y el DPI
            String nombre = partes[0].replaceAll("1", " ");
            String dpiST = partes[1];
            long dpi = Long.parseLong(dpiST);
            // Valores predeterminados para los datos adicionales de vacunación
                String departamento = "";
                String municipalidad = "";
                String dosis = "";
                String fecha1 = "";
                String fecha2 = "";
                String fecha3 = "";
                String lugarVacunacion = "";

                // Agregar el nodo con todos los datos
                arch.insertar(dpi, nombre, departamento, municipalidad, dosis, fecha1, fecha2, fecha3, lugarVacunacion);        }
        }
        reader.close();
    } catch (IOException e) {
        System.out.println("Ocurrió un error al leer el archivo: " + e.getMessage());
        e.printStackTrace();
    }   
    }

## 12. Clase (GraficaAVL)
Nueva clase con la misma estructura de la clase ExpresionGraficaABB pero con la diferencia de que se va a cambiar el nodo por el nodoAVL, y el objeto de tipo ArbolAVL.

        private ArbolAVL miArbol;
                
ejemplo en un método:

        private Dimension calcularTamañoSubarbol(NodoAVL n) 
## 13. Clase (EncripAVL)

Esta clase támbien utiliza la misma estructura que la clase EncriptacionArboles. con la difrenecia que se utiliza el nodoAVL.

ejemplo:
    
    private File miArchivoAVL;
    private PrintWriter escribir;

    
     public EncripAVL() {
        miArchivoAVL = new File("archivoAVL.txt"); // Inicializa el archivo en el constructor
        try {
            if (!miArchivoAVL.exists()) {
                miArchivoAVL.createNewFile();
            }
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

* Método crearArchivo:

        public void crearArchivo(NodoAVL nodo) {
    
        FileWriter escribir;
        
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(miArchivoAVL, true))) {
            String linea = nodo.dpiAVL + "/" + nodo.nombre + "/" + nodo.departamento+ "/" + nodo.municipalidad + "/" + nodo.dosis+ "/" + nodo.fecha1 + "/" + nodo.fecha2 + "/" + nodo.fecha3 + "/" + nodo.lugarVacunacion;
            writer.write(linea);
            writer.newLine(); // Añadir nueva línea
        } catch (IOException e) {
            e.printStackTrace();
        }
         }
    se siguen utilizando los mismos métodos de EncriptacionArboles.
## 14. JFrame form AVL

### Funcionalidades

* Cargar Datos
La aplicación permite al usuario cargar datos desde un archivo de texto. Para hacerlo, el usuario debe hacer clic en el botón "..." y seleccionar el archivo deseado. Luego, se le solicita ingresar el número de línea inicial y final que desea cargar.
        
        private void jButton1ActionPerformed(java.awt.event.ActionEvent evt) {                                         
        arbolito=new ArbolAVL();
        JFileChooser fc= new JFileChooser();//creando objeto

        //creando un filtro para archivos txt
        FileNameExtensionFilter filtro=new FileNameExtensionFilter(".TXT", "txt");

        //indicamos el filtro
        fc.setFileFilter(filtro);

        //abriendo ventana, guardamos la opcion seleccionada por el usuario
        int seleccion=fc.showOpenDialog(this);

        //si el usuario selecciona aceptar
        if (seleccion==JFileChooser.APPROVE_OPTION){
            //seleccionamos el fichero
            File fichero=fc.getSelectedFile();

            //Escribe la ruta del fichero sleccionado en el campo de texto
            this.textArch.setText(fichero.getAbsolutePath());
            int LI =Integer.parseInt(JOptionPane.showInputDialog(null, "ingresa el numero de linea INICIAL que desea cargar"));
            int LF =Integer.parseInt(JOptionPane.showInputDialog(null, "ingresa el numero de linea FINAL que desea cargar"));

            //agregando al arbol
            ArchivoTexto.cargarArchivoAVL(arbolito, fichero.getAbsolutePath(), LI, LF);
        }
    }      
#### Operaciones en el Árbol AVL
Una vez cargados los datos, el usuario puede realizar las siguientes operaciones en el árbol AVL:

* InOrden: Muestra los nodos del árbol en orden ascendente.
* PreOrden: Muestra los nodos del árbol en orden de raíz, subárbol izquierdo y subárbol derecho.
* PostOrden: Muestra los nodos del árbol en orden de subárboles izquierdo y derecho, y luego la raíz.
        
         private void InOrdenAVLActionPerformed(java.awt.event.ActionEvent evt) {                                           
        StringBuilder sb=new StringBuilder();

        JTextArea.setText("");//limpiar Text

        //llamar al metodo InOrden y capturar la salida en el StringBuilder
        if(arbolito != null && !arbolito.EstaVacio()){
            arbolito.InOrden(arbolito.raiz,sb);
        }
        JTextArea.setText(sb.toString());//mostrar la salida en el text

         }                                          

         private void PreOrdenAVLActionPerformed(java.awt.event.ActionEvent evt) {                                            

        StringBuilder sb=new StringBuilder();

        JTextArea.setText("");//limpiar Text

        //llamar al metodo InOrden y capturar la salida en el StringBuilder
        if(arbolito != null && !arbolito.EstaVacio()){
            arbolito.PreOrden(arbolito.raiz,sb);
        }
        JTextArea.setText(sb.toString());//mostrar la salida en el text
         }                                           

         private void PostOrdenAVLActionPerformed(java.awt.event.ActionEvent evt) {                                             

        StringBuilder sb=new StringBuilder();

        JTextArea.setText("");//limpiar Text

        //llamar al metodo InOrden y capturar la salida en el StringBuilder
        if(arbolito != null && !arbolito.EstaVacio()){
            arbolito.PostOrden(arbolito.raiz,sb);
        }
        JTextArea.setText(sb.toString());//mostrar la salida en el text
         }

* Insertar nuevo nodo.

            String nuevoD=textNuevoDPI.getText();
        try {
            long dato = Long.parseLong(nuevoD);
            String nombre = textNuevoNom.getText();
            arbolito.insertar(dato, nombre, "", "", "", "", "", "", "");

        } catch (NumberFormatException e) {
            // Maneja el caso de error cuando el texto ingresado no es un número válido
            System.out.println("El valor ingresado para el DPI no es un número válido.");
        } catch (Exception e) {
            // Maneja cualquier otra excepción que pueda ocurrir
            System.out.println("Error al insertar nodo en el árbol: " + e.getMessage());
        }

* Buscar: Permite buscar un nodo específico en el árbol por su clave (DPI).
        
        private void BusquedaActionPerformed(java.awt.event.ActionEvent evt) {                                         

        if(!arbolito.EstaVacio()){
            String dpi1=textBuscar.getText();

            long dpi = Long.parseLong(dpi1);
            NodoAVL tmp;
            tmp=arbolito.buscar(dpi);
            if(tmp==null){
                JOptionPane.showMessageDialog(null,"el nodo a buscar no se encuenta","error",JOptionPane.QUESTION_MESSAGE);
            }else{
                JTextArea.setText("");//limpiar Text
                JTextArea.setText(tmp.getNombre());//mostrar la salida en el text
                modificar.setEnabled(true);
            }
        }else{
            JOptionPane.showMessageDialog(null, "esta vacio", "error", JOptionPane.INFORMATION_MESSAGE);
        }

     } 

* Eliminar: Elimina un nodo específico del árbol por su clave (DPI).
        
        private void EliminacionActionPerformed(java.awt.event.ActionEvent evt) {                                            

        if(!arbolito.EstaVacio()){
            String dat=textBuscar.getText();
            long dato=Long.parseLong(dat);

          if (arbolito.eliminarAVL(dato)==false){
                JOptionPane.showMessageDialog(null, "El Nodo a Eliminar no se encuentra en el Arbol","Nodo no Encontrado",JOptionPane.INFORMATION_MESSAGE);
            }else{
                JOptionPane.showMessageDialog(null, "El Nodo ha sido eliminado del Arbol","Nodo Eliminado",JOptionPane.INFORMATION_MESSAGE);
                            
            }
        }else{
            JOptionPane.showMessageDialog(null, "El Arbol esta vacio","Error",JOptionPane.INFORMATION_MESSAGE);
        }
        }   

* Modificar Datos: Permite modificar los datos de un nodo específico (departamento, municipalidad, dosis, fechas y lugar de vacunación).
  
      private void modificarActionPerformed(java.awt.event.ActionEvent evt) {                                          
        // TODO add your handling code here:
           String dep=JOptionPane.showInputDialog(null,"Departamento");
           String muni=JOptionPane.showInputDialog(null,"municipalidad");
           String Dosis=JOptionPane.showInputDialog(null,"Dosis");
           String Fecha1=JOptionPane.showInputDialog(null,"Fecha 1");
           String Fecha2=JOptionPane.showInputDialog(null,"Fecha 2");
           String Fecha3=JOptionPane.showInputDialog(null,"Fecha 3");
           String Lugar=JOptionPane.showInputDialog(null,"Lugar de Vacunacion");

           arbolito.modificar(dep, muni, Dosis, Fecha1, Fecha2, Fecha3, Lugar);
           arbolito.datosdeNodo();
          }  

* Encriptar y Desencriptar

        private void encriptarActionPerformed(java.awt.event.ActionEvent evt) {                                          
            // TODO add your handling code here:
        EncripAVL en=new EncripAVL();
                
        try {
            en.encriptarArbol(arbolito.raiz);
            en.encriptarArchivo(en.getMiArchivoAVL());
        desencriptar.setEnabled(true);
        } catch (IOException ex) {
            Logger.getLogger(AVL.class.getName()).log(Level.SEVERE, null, ex);
        }
        }                                         

        private void desencriptarActionPerformed(java.awt.event.ActionEvent evt) {                                             
            // TODO add your handling code here:
            EncripAVL en=new EncripAVL();
            
            try {
            en.desencriptarArbol(arbolito.raiz);
            en.desencriptarArchivo(en.getMiArchivoAVL());
            } catch (IOException ex) {
            Logger.getLogger(ArboldeBusqueda.class.getName()).log(Level.SEVERE, null, ex);
        }
        }  

* Visualización del Árbol
El botón "Ver Árbol AVL" abre una nueva ventana que muestra una representación gráfica del árbol AVL.
  
         private void jButton2ActionPerformed(java.awt.event.ActionEvent evt) {                                         

        GraficaAVL graf= new GraficaAVL(arbolito);
        JFrame ventanaAVL=new JFrame();
        ventanaAVL.getContentPane().add(graf);
        ventanaAVL.setSize(800, 600);
        ventanaAVL.setVisible(true);
        ventanaAVL.setLocationRelativeTo(null);
            }

## CONLUCIONES
*Este manual técnico ha sido diseñado con el objetivo de brindar una guía detallada y clara sobre cómo fue creado la apliación. A lo largo de este manual, se ha cubierto todos los aspectos importantes y proporcionado instrucciones paso a paso para garantizar una experiencia óptima.*

*Espero que este manual  resuelva cualquier duda o problema que se haya tenido.*